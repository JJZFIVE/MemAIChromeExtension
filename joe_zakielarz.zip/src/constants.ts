const SUMMARIZE_BODY_URL =
  "https://u47ywgl6gj.execute-api.us-east-1.amazonaws.com/default/MemAiSummarizerBody";

const SUMMARIZE_TITLE_URL =
  "https://u47ywgl6gj.execute-api.us-east-1.amazonaws.com/default/MemAiSummarizeTitle";

export { SUMMARIZE_BODY_URL, SUMMARIZE_TITLE_URL };
